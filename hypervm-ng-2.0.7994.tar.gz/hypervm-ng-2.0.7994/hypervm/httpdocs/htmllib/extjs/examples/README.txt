The examples can be browsed by opening index.html in the docs folder.

Some examples use XHR. Those examples will need to be on a webserver to run since XHR can't access the local file system.