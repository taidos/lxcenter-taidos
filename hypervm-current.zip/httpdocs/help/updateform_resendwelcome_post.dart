You will need to provide a new password since <%program%> doesn't store the passwords in cleartext. The password for the resource will be changed to the one you supply now, and a welcome message with the new login information will be sent to the user. <%program%> will also send the same email to [b] Extra Email [/b], if you provide one.

