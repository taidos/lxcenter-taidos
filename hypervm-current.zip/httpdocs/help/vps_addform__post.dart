
 <%ifblock:isadmin%> 
 It is highly recommended that you create an ip pool before you add a vps. The resolv entries for the vps can be specificied in the ippool.
 </%ifblock%> 


