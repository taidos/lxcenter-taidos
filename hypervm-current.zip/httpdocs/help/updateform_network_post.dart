
 The resolv entries are the ip addresses added to the /etc/resolv.conf and that are used to do name resolution. Please note that the /etc/resolv.conf would be complete overwritten if you add an entry here.
