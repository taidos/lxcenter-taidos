
 This is meant to configure the list of ostemplates that your clients will see. If you leave them empty, the vps owners will see all the ostemplates in the system. You can limit them by adding the specific ostemplates to the list. If the list is non-empty, then only those ostemplates will be visible to the user when he tries to rebuild.

 Click on [b] openvz ostemplates [/b] or [b] xen ostemplatelist [/b] to manage the list.
