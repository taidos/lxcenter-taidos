Disk Quota (MB)  	
Number Of Backups 	
Burstable Memory (MB)(openvz Only) 	
Guaranteed Memory (MB)(openvz Only) 	
Number Of Processes(openvz Only) 	
Real Memory Usage (MB)(xen Only) 	
Cpu Usage (%) 100/CPU 	
Traffic (MB/month) 	
Uplink Traffic(KB/s) 	
Swap (MB)(xen Only) 	
Number Of Ipaddresses 	
Enable Iptables (only For Openvz) 	
Allow Backup Schedule 	
Allow Backing Up 	
Can Change Logo
