
 This lists all the VMs in the cluster, created by every single client. You can click on the vps and it will take you to the vps home page through the owner client's page.
