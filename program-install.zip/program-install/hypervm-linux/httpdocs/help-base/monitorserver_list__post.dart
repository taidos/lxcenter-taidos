
 You have to first add the ip/server to be monitored here. Once you add the server, then you can click on the server in the listing, go inside, and then add the requisite ports on the server. You can also click on a specific port to see its history, which will show the entire past detail on when the port was up or down.
