
 The default policy in <%program%> is to keep warning the owner if the resources exceed their quota, and they are not disabled. But you can set the [b] disable policy [/b] per client/domain to disable the account when the usage reaches a certain percentage. Please note that this can lead to disruption of services, and should be enabled only in extreme circumstances.
