
 Click on the file manager tab and you will be able to browse your entire live backup. To restore a file/directory, just copy the file/directory in the file manager, and then you can paste it back inside the file manager of the vps.
